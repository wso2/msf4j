HTTP monitoring UI
==================
