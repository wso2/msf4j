var resources = function (page, meta) {
    return {
        js: ['date-range.js','server-select.js'],
        css: []
    };
};
